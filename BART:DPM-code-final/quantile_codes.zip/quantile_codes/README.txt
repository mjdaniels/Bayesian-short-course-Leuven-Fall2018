There are two steps to implement the proposed approach (BART_DPM).
1. The first step estimates propensity score using BART. 
   If no missing data, use R package 'BayesTree'. 
   If covariates have missing data, use Sequential BART approach (https://github.com/mjdaniels/SequentialBART).
2. The second step estimates marginal distribution of potential outcomes using DPM.
   Use modified function 'DPcdensity' in DPpakage: (1) download the package source; 
                                                   (2) replace DPcdensity.r in the R folder and DPdensityreg.f in the src folder;
                                                   (3) build the package
   The output save.state$denspm (a matrix of nsave*ngrid) has pdf of potential outcomes and save.state$denspl has cdf of potential outcomes at the grid points.
   *The codes have been tested in DPpackage_1.1-6

The enclosed programs include:
1. DPcdensity.r and DPdensityreg.f for modified function DPcdensity.
2. R codes for the EHR example (EHR_example-course.r) and EHR data with noise for illustration (EHR_data.cvs)
